#define QT_FEATURE_properties 1
#define QT_FEATURE_animation 1
#define QT_FEATURE_textcodec 1
#define QT_FEATURE_big_codecs 1
#define QT_NO_CLOCK_MONOTONIC 
#define QT_FEATURE_codecs 1
#define QT_FEATURE_commandlineparser 1
#define QT_FEATURE_cxx11_future 1
#define QT_FEATURE_textdate 1
#define QT_FEATURE_datestring 1
#define QT_NO_EVENTFD 
#define QT_FEATURE_filesystemiterator 1
#define QT_FEATURE_filesystemwatcher 1
#define QT_FEATURE_gestures 1
#define QT_NO_GLIB 
#define QT_NO_ICONV 
#define QT_FEATURE_itemmodel 1
#define QT_FEATURE_proxymodel 1
#define QT_FEATURE_identityproxymodel 1
#define QT_NO_INOTIFY 
#define QT_FEATURE_library 1
#define QT_FEATURE_mimetype 1
#define QT_FEATURE_processenvironment 1
#define QT_FEATURE_process 1
#define QT_FEATURE_statemachine 1
#define QT_FEATURE_qeventtransition 1
#define QT_FEATURE_regularexpression 1
#define QT_FEATURE_settings 1
#define QT_FEATURE_sharedmemory 1
#define QT_FEATURE_sortfilterproxymodel 1
#define QT_FEATURE_std_atomic64 1
#define QT_FEATURE_stringlistmodel 1
#define QT_FEATURE_systemsemaphore 1
#define QT_FEATURE_temporaryfile 1
#define QT_FEATURE_timezone 1
#define QT_FEATURE_topleveldomain 1
#define QT_FEATURE_translation 1
#define QT_FEATURE_xmlstream 1
#define QT_FEATURE_xmlstreamreader 1
#define QT_FEATURE_xmlstreamwriter 1
